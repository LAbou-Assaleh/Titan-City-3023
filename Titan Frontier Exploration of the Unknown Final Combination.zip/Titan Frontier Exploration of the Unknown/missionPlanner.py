import pygame
import random
import sys
from pygame import font
import time
def main():
    pygame.init()

    run = True

    # game window
    SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 600

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('Mission to Titan')

    # Load and resize the background image
    background_image = pygame.image.load("NASA mission planning.png")
    # Replace "background.jpg" with your image file name
    background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

    # Load and resize the launch button image
    launch_button_image = pygame.image.load("Launch.png").convert_alpha()
    launch_button_image = pygame.transform.scale(launch_button_image, (150, 75))

    # Colours
    WHITE = (255, 255, 255)
    DARK_BLUE = (0, 3, 38)

    # Fonts
    font = pygame.font.SysFont("Times New Roman", 20)

    # Setup variables
    run = True
    check_made = False
    active_box = None
    boxes = []
    texts = ['Liftoff', 'First Stage Separation', 'Second Stage Ignition', 'Second Stage Separation']

    # Define thes submit button and its color
    submit_button = pygame.Rect(325, 520, 100, 75)  # X, Y, Width, Height
    submit_color = (0, 255, 0)  # Blue color for the button

    # Randomize the order of boxes
    random.shuffle(texts)

    # Unique IDs to texts and boxes
    box_dict = {}
    for i, text in enumerate(texts):
        x = 250
        y = 100 + i * 113  # Vertical spacing between boxes
        w = 300
        h = 50
        box = pygame.Rect(x, y, w, h)
        boxes.append(box)
        box_dict[text] = box

    original_positions = [
        box_dict['Liftoff'].topleft,
        box_dict['First Stage Separation'].topleft,
        box_dict['Second Stage Ignition'].topleft,
        box_dict['Second Stage Separation'].topleft
    ]


    # Draws text onto boxes
    def draw_text(text, font, text_col, x, y):
        img = font.render(text, True, text_col)
        screen.blit(img, (x, y))


    mission_text = ["Captain, your mission, should you choose to accept it,",
                    "... Is to colonize Saturn's largest moon - Titan",
                    "This begins with planning out our takeoff sequence.",
                    "You must place the launch order steps in the correct order.",
                    "The success of this mission lies in your hands.", "Good Luck."]


    def text_animation(text, font, text_col, x, y, msg_index, message_list):
        output = ""

        for letter in text:
            screen.fill(pygame.Color("black"))

            for i in range(msg_index):
                ty = 30 + (i * 40)
                draw_text(message_list[i], font, (255, 255, 255), 30, ty)

            output += letter
            draw_text(output, font, text_col, x, y)
            pygame.event.get()
            time.sleep(0.05)
            pygame.display.flip()


    def wait_for_response():
        exit = False

        while not exit:
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    exit = True


    # -----------------------

    screen.fill(pygame.Color("black"))

    # Mission acceptance phase
    for i in range(len(mission_text)):
        y = 30 + (i * 40)
        print("h0")

        text_animation(mission_text[i], font, (255, 255, 255), 30, y, i, mission_text)
        print("hi")
    time.sleep(0.5)
    # -----------------------

    success_text = ["Launch sequence is in correct order!", "Congratulations, Captain!",
                    "You have successfully launched your spaceship out of Mars' atmosphere.",
                    "Your crew is heading for Titan, good luck on the mission.", "Click anywhere to end the mission: "]


    def ending_screen():
        for i in range(len(success_text)):

            y = 30 + (i * 40)

            text_animation(success_text[i], font, (255, 255, 255), 30, y, i, success_text)
            pygame.display.flip()

        exit = True

        while exit:
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    exit = False


    def retry_screen():
        screen.fill(pygame.Color("black"))

        draw_text("Launch sequence is not in correct order, click r to try and submit again.", font, (255, 255, 255), 30,
                  10)

        pygame.display.flip()

        exit = True

        while exit:
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    exit = False


    # Main game loop
    while run:
        # Draws the background image
        screen.blit(background_image, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for num, box in enumerate(boxes):
                    if box.collidepoint(event.pos):
                        active_box = num

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                active_box = None

            if event.type == pygame.MOUSEMOTION and active_box != None:
                boxes[active_box].move_ip(event.rel)

            if event.type == pygame.QUIT:
                run = False

            # Checks if boxes are in order based on order
            option1_bottom = box_dict['Liftoff'].bottom
            option2_bottom = box_dict['First Stage Separation'].bottom
            option3_bottom = box_dict['Second Stage Ignition'].bottom
            option4_bottom = box_dict['Second Stage Separation'].bottom

            # Checks if the mouse click occurs within the submit button's area
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if submit_button.collidepoint(event.pos) and not check_made:
                    option1_bottom = box_dict['Liftoff'].bottom
                    option2_bottom = box_dict['First Stage Separation'].bottom
                    option3_bottom = box_dict['Second Stage Ignition'].bottom
                    option4_bottom = box_dict['Second Stage Separation'].bottom

                    if option1_bottom < option2_bottom < option3_bottom < option4_bottom:
                        ending_screen()
                        run = False
                    else:
                        retry_screen()
                        check_made = False  # Set check_made to True after the check

            # If the user wants to retry, reset check_made to False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                check_made = False

        i = 0
        # Updates and draws the launch sequence
        for box in boxes:
            pygame.draw.rect(screen, DARK_BLUE, box)
            draw_text(texts[i], font, (255, 255, 255), box.x + 10, box.y + 20)
            i += 1

        # Draw the launch button
        launch_button_rect = screen.blit(launch_button_image, (325, 520))

        pygame.display.flip()
