import pygame
import random
def main():
    pygame.init()
    print("explore")
    screen_width, screen_height = 800, 600
    display_width, display_height = 2500, 2000
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Titan City!")

    grey_color = (105, 105, 105)

    background_image = pygame.image.load("terrain2.png")
    background_image = pygame.transform.scale(background_image,
                                              (display_width, display_height))

    player_left_image = pygame.image.load('rover.png')
    player_down_image = pygame.transform.rotate(player_left_image, 90)
    player_up_image = pygame.transform.rotate(player_left_image, 270)
    player_right_image = pygame.transform.rotate(player_left_image, 180)

    player_image = player_down_image
    player_rect = player_image.get_rect()
    player_x, player_y = 400, 500

    clock = pygame.time.Clock()

    score = 0

    x_velocity, y_velocity = 0, 0

    spawn_area_rect = pygame.Rect(500, 500, display_width - 1000,
                                  display_height - 1000)

    circles = []

    # Generate random circles within the specified area
    for _ in range(5):
      color = (128, 128, 128)
      radius = 10
      x = random.randint(spawn_area_rect.left + radius,
                         spawn_area_rect.right - radius)
      y = random.randint(spawn_area_rect.top + radius,
                         spawn_area_rect.bottom - radius)
      circles.append((color, (x, y), radius))

    welcome_screen = True
    game_started = False

    while welcome_screen:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          welcome_screen = False

        if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
          welcome_screen = False
          game_started = True

      grey_rect = pygame.Rect(0, display_height - screen_height, display_width,
                              screen_height - display_height)
      pygame.draw.rect(screen, grey_color, grey_rect)

      font = pygame.font.Font(None, 36)

      welcome_message = "Welcome to Titan City! Your mission should you choose to accept is to locate all the missing parts on Titan(Press Enter To Begin)"

      # Split the message into multiple lines if it exceeds the width of the screen
      max_line_length = screen_width - 40
      lines = []
      words = welcome_message.split()
      current_line = ""

      for word in words:
        test_line = current_line + " " + word if current_line else word
        test_text = font.render(test_line, True, (255, 255, 255))

        if test_text.get_width() <= max_line_length:
          current_line = test_line
        else:
          lines.append(current_line)
          current_line = word

      lines.append(current_line)

      total_height = len(lines) * font.get_linesize()

      y_offset = (screen_height - total_height) // 2

      for line in lines:
        welcome_text = font.render(line, True, (255, 255, 255))
        screen.blit(welcome_text,
                    (screen_width // 2 - welcome_text.get_width() // 2, y_offset))
        y_offset += font.get_linesize()

      pygame.display.update()

    PLAYER_SPEED = 3
    running = True
    while running:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          running = False

      keys = pygame.key.get_pressed()
      if keys[pygame.K_LEFT] and player_x > 0:
        x_velocity = -PLAYER_SPEED
        player_image = player_left_image
      elif keys[pygame.K_RIGHT] and player_x < display_width - player_rect.width:
        x_velocity = PLAYER_SPEED
        player_image = player_right_image
      else:
        x_velocity = 0

      if keys[pygame.K_UP] and player_y > 0:
        y_velocity = -PLAYER_SPEED
        player_image = player_up_image
      elif keys[pygame.K_DOWN] and player_y < display_height - player_rect.height:
        y_velocity = PLAYER_SPEED
        player_image = player_down_image
      else:
        y_velocity = 0

      player_x += x_velocity
      player_y += y_velocity

      camera_x = player_x - screen_width // 2
      camera_y = player_y - screen_height // 2

      grey_rect = pygame.Rect(0, display_height - screen_height, display_width,
                              screen_height - display_height)
      pygame.draw.rect(screen, grey_color, grey_rect)

      screen.blit(background_image, (-camera_x, -camera_y))

      player_rect.center = (player_x - camera_x, player_y - camera_y)
      screen.blit(player_image, player_rect)

      # Draw random circles
      for i, (color, (x, y), radius) in enumerate(circles):
        circle_rect = pygame.Rect(x - camera_x - radius, y - camera_y - radius,
                                  2 * radius, 2 * radius)
        pygame.draw.circle(screen, color, circle_rect.center, radius)

        if player_rect.colliderect(circle_rect):

          del circles[i]
          score += 1
          break

      font = pygame.font.Font(None, 36)

      score_text = font.render("Score: " + str(score) + " of Five", True,
                               (255, 255, 255))

      screen.blit(score_text, (10, 10))

      pygame.display.update()

      clock.tick(60)

      if len(circles) == 0:
        running = False

    font = pygame.font.Font(None, 48)
    screen.fill((0, 0, 0))
    congratulations_text = font.render("Congratulations! ", True,(255, 255, 255))
    screen.blit(congratulations_text,(screen_width // 2 - congratulations_text.get_width() // 2,screen_height // 2 - 50))
    congratulations_text = font.render("You have collected the materials", True, (255, 255, 255))
    screen.blit(congratulations_text,(screen_width // 2 - congratulations_text.get_width() // 2, screen_height // 2))
    congratulations_text = font.render("to begin building titan city!", True, (255, 255, 255))
    screen.blit(congratulations_text,(screen_width // 2 - congratulations_text.get_width() // 2, screen_height // 2 + 50))
    pygame.display.update()

    pygame.time.delay(1000)  # Delay for 1 seconds

    return

    pygame.init()

    screen_width, screen_height = 800, 600
    screen = pygame.display.set_mode((screen_width, screen_height))
    grey_color = (128, 128, 128)

    new_screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("FACTS ABOUT TITAN")

    font = pygame.font.Font(None, 24)

    facts = [
      "Thick Atmosphere: Titan has a dense and hazy atmosphere primarily composed of nitrogen, with trace amounts of methane and other hydrocarbons. It's the only moon in our solar system known to have a substantial atmosphere.",
      "Liquid Lakes: Titan's surface features numerous lakes and seas, but they aren't filled with water like Earth's. Instead, they contain liquid methane and ethane, making them some of the only stable bodies of liquid found outside of Earth.",
      "Organic Chemistry: The complex chemistry in Titan's atmosphere and on its surface, coupled with ultraviolet radiation from the Sun, creates a rich assortment of organic compounds. Scientists are intrigued by this chemistry as it offers insights into prebiotic processes and the potential for life beyond Earth.",
      "Cold Environment: Titan is an extremely cold world, with surface temperatures averaging around -290 degrees Fahrenheit (-179 degrees Celsius). Its harsh conditions make it inhospitable to human life without specialized equipment.",
      "Cassini-Huygens Mission: The Cassini-Huygens mission, conducted by NASA and the European Space Agency, provided valuable data about Titan. In 2005, the Huygens probe successfully landed on Titan's surface, giving us our first close-up view of the moon and its environment."
    ]

    fact_boxes = [
      pygame.Rect(50, 10, 700, 100),
      pygame.Rect(50, 150, 700, 100),
      pygame.Rect(50, 300, 700, 100),
      pygame.Rect(50, 450, 700, 100),
      pygame.Rect(50, 600, 700, 100),
    ]

    for i, fact in enumerate(facts):
      pygame.draw.rect(screen, grey_color, fact_boxes[i])  # Draw the box

      words = fact.split(" ")
      lines = []
      current_line = ""
      for word in words:
        test_line = current_line + " " + word if current_line else word
        test_text = font.render(test_line, True, (255, 255, 255))
        if test_text.get_width() <= fact_boxes[i].width - 20:
          current_line = test_line
        else:
          lines.append(current_line)
          current_line = word
      lines.append(current_line)

      y_offset = 10
      for line in lines:
        fact_text = font.render(line, True, (255, 255, 255))
        screen.blit(fact_text, (fact_boxes[i].x + 10, fact_boxes[i].y + y_offset))
        y_offset += fact_text.get_height()

    pygame.display.flip()

    running = True
    while running:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          running = False
    return

