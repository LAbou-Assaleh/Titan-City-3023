import time

import pygame
import random
import sys
def main():
    pygame.init()

    # Constants
    SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 600

    # Colours
    WHITE = (255, 255, 255)
    BLUE = (0, 0, 255)


    # Game states
    class GameState:
        INTRODUCTION = 0
        LANDING_SELECTION = 1
        LANDING_ANIMATION = 2
        LANDING_RESULT = 3  # New state for displaying landing result


    # Initialize Pygame
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('Landing on Titan')

    # Loads the Titan Map image
    titan_image = pygame.image.load("Titan Map.webp")

    # Defines the desired width and height for the resized image
    desired_width = 810  # Replace this with your desired width
    desired_height = 610  # Replace this with your desired height

    # Resizes the Titan Map image
    titan_image = pygame.transform.scale(titan_image, (desired_width, desired_height))

    # Sets the initial position of the Titan map image
    titan_rect = titan_image.get_rect()
    titan_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

    # Fonts
    font = pygame.font.Font(None, 30)

    # Landing locations and educational content
    landing_locations = {
        "Kraken Mare": "Near oily ethane and methane lakes that only cover 1.5% of Titan's surface.",
        "Menrva": "The largest crater on Titan at 425 km wide, thought to have formed 1 billion years ago",
        "Huygens Landing Site": "Part of the large plains of Titan the makes roughly 70% of Titan's surface. It is where Cassini Huygens probe landed in 2005."
    }

    # Game variables
    current_state = GameState.INTRODUCTION
    selected_location = None

    # Clock for controlling frame rate
    clock = pygame.time.Clock()

    # Game loop
    run = True
    while run:
        # Handles events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        # Clear the screen
        screen.fill(WHITE)

        # Update game state and draw game elements here
        if current_state == GameState.INTRODUCTION:
            # Display introduction
            introduction_text = "Captain, your mission is to select the most viable landing site on Titan."
            introduction_text2 = "Click on the space bar to continue the mission."
            text_surface = font.render(introduction_text, True, (0, 0, 0))
            text_surface2 = font.render(introduction_text2, True, (0, 0, 0))
            screen.blit(text_surface, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, 50))
            screen.blit(text_surface2, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, 100))

            # Transition to landing selection state on SPACE key press
            keys = pygame.key.get_pressed()
            if keys[pygame.K_SPACE]:
                current_state = GameState.LANDING_SELECTION

        elif current_state == GameState.LANDING_SELECTION:
            # Display the Titan map
            screen.blit(titan_image, titan_rect)

            # Display landing options
            y_position = 175
            landing_locations = ["Kraken Mare", "Menrva", "Huygens Landing Site"]
            for location in landing_locations:
                text_surface = font.render(location, True, (0, 0, 0))
                screen.blit(text_surface, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, y_position))

                # Get player input for landing location
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if pygame.mouse.get_pressed()[0]:
                    # Check if the mouse click occurred within the bounding box of the text
                    if SCREEN_WIDTH // 2 - text_surface.get_width() // 2 < mouse_x < SCREEN_WIDTH // 2 + text_surface.get_width() // 2 and y_position - 50 < mouse_y < y_position + 20:
                        selected_location = location

                        # Checks if selected location is Kraken Mare and set the game state accordingly
                        if selected_location == "Kraken Mare":
                            current_state = GameState.LANDING_ANIMATION
                        else:
                            current_state = GameState.LANDING_RESULT

                y_position += 70

        elif current_state == GameState.LANDING_RESULT:
            # Display landing result
            result_text = f"Choosing {selected_location} is a good option, but it doesn't provide."
            result_text2 = "Close access to liquids needed for a colony."
            back_button_text = "Back to Choose a Landing Site"

            result_surface = font.render(result_text, True, (0, 0, 0))
            result_surface2 = font.render(result_text2, True, (0, 0, 0))
            back_button_surface = font.render(back_button_text, True, WHITE)

            screen.blit(result_surface, (SCREEN_WIDTH // 2 - result_surface.get_width() // 2, 200))
            screen.blit(result_surface2, (SCREEN_WIDTH // 2 - result_surface.get_width() // 2, 250))
            screen.blit(back_button_surface, (SCREEN_WIDTH // 2 - back_button_surface.get_width() // 2, 350))

            # Draw back button
            back_button_rect = pygame.Rect(SCREEN_WIDTH // 2 -
                                           back_button_surface.get_width() // 2, 350,
                                           back_button_surface.get_width(), 40)
            pygame.draw.rect(screen, (0, 0, 255), back_button_rect)  # Draw a blue rectangle for the back button
            screen.blit(back_button_surface, (back_button_rect.x, back_button_rect.y))

            # Get player input for back button
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if pygame.mouse.get_pressed()[0]:
                if back_button_rect.collidepoint(mouse_x, mouse_y):  # Check if the mouse is over the back button
                    current_state = GameState.LANDING_SELECTION

        elif current_state == GameState.LANDING_ANIMATION:
            # Display landing animation (simplified with a message)
            landing_message = f"Landing on {selected_location}..."
            text_surface = font.render(landing_message, True, (0, 0, 0))
            screen.blit(text_surface, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, SCREEN_HEIGHT // 2))
            pygame.display.flip()
            time.sleep(1)
            return

            # Refresh the display
        pygame.display.flip()

        # Limit frames per second
        clock.tick(30)  # Adjust the number (30) to control the FPS

