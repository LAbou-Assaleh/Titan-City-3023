import pygame
def main():
    pygame.init()

    size = width, height = 800, 600
    screen = pygame.display.set_mode(size)
    myClock = pygame.time.Clock()
    font1 = pygame.font.Font(None, 36)  # Decrease font size for menu items
    font2 = pygame.font.Font(None, 56)  # Decrease font size for the title

    GREY = (127, 127, 127)

    backgroundPic = pygame.image.load("Space.jpeg")
    backgroundPic = pygame.transform.scale(backgroundPic, (width, height))


    def drawScene(screen, backx):
      # left side
      screen.blit(backgroundPic, pygame.Rect(backx, 0, width,
                                             height))  # draw the picture
      # right side
      screen.blit(backgroundPic, pygame.Rect(backx + width, 0, width, height))


    running = True
    backgroundX = 0
    current_screen = "Menu"
    while running:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          running = False

      # Draw the background
      drawScene(screen, backgroundX)
      backgroundX -= 1
      if backgroundX <= -width:
        backgroundX = 0

      text = "Mission Planner"
      renderedText = font1.render(text, 1, (255, 255, 255))
      fontSize = font1.size(text)
      button_width = 300  # Adjust the button width
      button_height = 80  # Adjust the button height
      startX = (width - button_width) // 2  # Center horizontally
      startY = (height - 4 *
                (button_height)) // 2  # Center vertically and shift upwards
      centeredRect = (startX, startY, button_width, button_height)
      pygame.draw.rect(screen, GREY, centeredRect)
      screen.blit(renderedText,
                  (startX + (button_width - fontSize[0]) // 2, startY +
                   (button_height - fontSize[1]) // 2))

      text2 = "Colonial"
      renderedText2 = font1.render(text2, 1, (255, 255, 255))
      rectangle2 = pygame.Rect(
        startX, startY + button_height + 20, button_width,
        button_height)  # Adjust the button size and position
      pygame.draw.rect(screen, GREY, rectangle2)
      screen.blit(renderedText2,
                  (startX +
                   (button_width - fontSize[0]) // 2, startY + button_height + 20 +
                   (button_height - fontSize[1]) // 2))

      text3 = "Space Trivia"
      renderedText3 = font1.render(text3, 1, (255, 255, 255))
      rectangle3 = pygame.Rect(
        startX, startY + 2 * (button_height + 20), button_width,
        button_height)  # Adjust the button size and position
      pygame.draw.rect(screen, GREY, rectangle3)
      screen.blit(renderedText3,
                  (startX + (button_width - fontSize[0]) // 2, startY + 2 *
                   (button_height + 20) + (button_height - fontSize[1]) // 2))

      text4 = "Titan Survivor"
      renderedText4 = font1.render(text4, 1, (255, 255, 255))
      rectangle4 = pygame.Rect(
        startX, startY + 3 * (button_height + 20), button_width,
        button_height)  # Adjust the button size and position
      pygame.draw.rect(screen, GREY, rectangle4)
      screen.blit(renderedText4,
                  (startX + (button_width - fontSize[0]) // 2, startY + 3 *
                   (button_height + 20) + (button_height - fontSize[1]) // 2))

      title_text = "Titan Frontier: "
      title_text2 = "Exploration of the Unkown"
      title_render = font2.render(title_text, 1, (255, 255, 255))
      title_render2 = font2.render(title_text2, 1, (255, 255, 255))
      title_width = title_render.get_width()
      title_width2 = title_render2.get_width()
      screen.blit(
        title_render,
        ((width - title_width) // 2, 25))  # Center the title horizontally
      screen.blit(title_render2, ((width - title_width2) // 2, 75))

      pygame.display.flip()
      myClock.tick(60)

    pygame.quit()
