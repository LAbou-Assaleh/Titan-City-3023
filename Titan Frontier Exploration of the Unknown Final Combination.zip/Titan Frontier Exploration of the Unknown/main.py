import sys
import time
import pygame
from pygame.locals import QUIT
import threading
import missionPlanner as mp
import navigation as nav
import landing as ld
import exploration
mp.main()
while not nav.main():
    mp.main()
ld.main()
exploration.main()
pygame.init()
place = {}
map = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
screen = pygame.display.set_mode((800, 600))
house = pygame.image.load("house.png")
fuel = pygame.image.load("methane.png")
water = pygame.image.load("water.png")
wind = pygame.image.load("wind.png")
font = pygame.font.SysFont("Times New Roman", 10)

class Store:
    water = 0
    plastic = 0
    energy = 0
    brick = 300
    index = {2 : [100, 100, 10, 100], 3: [100, 0, 0, 100], 0 : [50, 100, 100, 100], 1 : [100, 50, 0, 100]}
    def __init__(self, plastic = 400, energy = 400, water = 400, brick = 450):
        self.plastic = plastic
        self.energy = energy
        self.water = water
        self.brick = brick


    def addWater(self, amount):
        self.water += amount

    def addBrick(self, amount):
        self.brick += amount

    def addPlastic(self, amount):
        self.plastic += amount

    def addEnergy(self, amount):
        self.energy += amount

    def getWater(self):
        return self.water

    def getPlastic(self):
        return self.plastic

    def getEnergy(self):
        return self.energy
    def getBrick(self):
        return self.brick

    def build(self, item):
        need = self.index[item]
        if self.plastic >= need[0] and self.energy >= need[1] and self.water >= need[2] and self.brick >= need[3]:
            self.plastic -= need[0]
            self.energy -= need[1]
            self.water -= need[2]
            self.brick -= need[3]
            return True
        else:
            return False
ms = 0
hs = 0
ws = 0
ts = 0
menu = pygame.image.load("menu.png")
store = Store()
gray = (128, 128, 128)
blue = (0, 0, 255)
green = (0, 255, 0)
red = (255, 0, 0)
white = (255, 255, 255)
black = (0, 0, 0)
shayaanBlue = (1, 23, 45)
item = -1
pygame.draw.rect(screen, white, (700, 0 ,100, 600))
screen.blit(menu, (700, 0))
bg = pygame.image.load("floor.png")
num0 = font.render("50 100 10 100", True, black)
num1 = font.render("50 100 100 100", True, black)
num2 = font.render("100 100 10 100", True, black)
num3 = font.render("100 0 0 100", True, black)
def add():
    global store
    while True:
        store.addEnergy(10 * ts)
        store.addWater(10 * ws)
        store.addBrick(10 * ms)
        store.addPlastic(10 * hs)
        time.sleep(1)

thread = threading.Thread(target=add)
thread.start()
while True:
    screen.blit(bg, (0, 0))
    pygame.draw.rect(screen, white, (700, 0, 100, 600))
    screen.blit(menu, (700, 0))
    for event in pygame.event.get():
        pygame.draw.rect(screen, white, (700, 490, 100, 220))
        txt = str(store.getPlastic()) + " " + str(store.getEnergy()) + " " + str(store.getWater()) + " " + str(store.getBrick())
        txt = font.render(txt, True, black)
        screen.blit(txt, (715, 540))
        screen.blit(num0, (715, 115))
        screen.blit(num1, (715, 235))
        screen.blit(num2, (715, 355))
        screen.blit(num3, (715, 475))
        x, y = pygame.mouse.get_pos()
        for i in place.keys():
            if place[i] == 0:
                screen.blit(house, (i[0]*50, i[1]*50))
            if place[i] == 1:
                screen.blit(water, (i[0]*50, i[1]*50))
            if place[i] == 2:
                screen.blit(fuel, (i[0]*50, i[1]*50))
            if place[i] == 3:
                screen.blit(wind, (i[0]*50, i[1]*50))
        if event == QUIT:
            pygame.quit()
            sys.exit(0)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_0:
                item = 0
            if event.key == pygame.K_1:
                item = 1
            if event.key == pygame.K_2:
                item = 2
            if event.key == pygame.K_3:
                item = 3
            if event.key == pygame.K_4:
                item = 4
        if pygame.mouse.get_pressed()[0]:
            if x > 700:
                if y <120:
                    item = 0
                if y > 120 and y <240:
                    item = 1
                if y > 240 and y < 360:
                    item = 2
                if y > 360 and y < 480:
                    item = 3
                if y > 480:
                    item = 4
            else:
                px = x/50
                py = y/50
                if px > (len(map[0])-1):
                    px = len(map[0])-1
                if py > len(map)-1:
                    py = len(map) - 1
                px = int(px)
                py = int(py)
                if map[py][px] == 0:
                    if item in store.index.keys():
                        if store.build(item):
                            map[py][px] = "I"
                            if item == 0:
                                screen.blit(house, (px*50, py*50))
                                place[(px, py)] = item
                                hs += 1
                            if item == 1:
                                screen.blit(water, (px*50, py*50))
                                place[(px, py)] = item
                                ws += 1
                            if item == 2:
                                screen.blit(fuel, (px*50, py*50))
                                place[(px, py)] = item
                                ms += 1
                            if item == 3:
                                screen.blit(wind, (px*50, py*50))
                                place[(px, py)] = item
                                ts += 1
                            pygame.draw.rect(screen, white, (700, 490, 100, 220))
                            txt = str(store.getPlastic()) + " " + str(store.getEnergy()) + " " + str(store.getWater()) + " " + str(store.getBrick())
                            txt = font.render(txt, True, black)
                            screen.blit(txt, (715, 540))
        if item == 0:
            screen.blit(house, (x-25, y-25))
        if item == 1:
            screen.blit(water, (x-25, y-25))
        if item == 2:
            screen.blit(fuel, (x-25, y-25))
        if item == 3:
            screen.blit(wind, (x-25, y-25))
        pygame.display.flip()




